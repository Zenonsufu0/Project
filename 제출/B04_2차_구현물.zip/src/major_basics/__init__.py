﻿"""Major basics project package."""
