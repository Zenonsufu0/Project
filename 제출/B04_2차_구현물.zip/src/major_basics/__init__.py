"""Major basics project package."""
